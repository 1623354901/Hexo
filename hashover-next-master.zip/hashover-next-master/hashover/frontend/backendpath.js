// Backend path (backendpath.js)
HashOverConstructor.backendPath = (function () {
	return HashOverConstructor.rootPath + '/backend';
}) ();
