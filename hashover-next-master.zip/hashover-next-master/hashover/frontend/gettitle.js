// Get the page title (gettitle.js)
HashOverConstructor.getTitle = function ()
{
	return document.title;
};
