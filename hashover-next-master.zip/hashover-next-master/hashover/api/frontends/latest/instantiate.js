// Instantiate after the DOM is parsed
HashOverLatest.onReady (function () {
	window.hashoverLatest = new HashOverLatest ();
});
