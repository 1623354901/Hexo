// Instantiate after the DOM is parsed (instantiate.js)
HashOverCountLink.onReady (function () {
	window.hashoverCountLink = new HashOverCountLink ();
});
